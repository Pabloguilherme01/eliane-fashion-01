// Entrega a config web PÚBLICA do Firebase a partir de variáveis de ambiente.
// A config web é pública por natureza (usada apenas para inicializar o SDK no browser);
// é fornecida aqui para não hardcodar nem commitar chaves no frontend.
// NUNCA expõe credenciais de service account, FIREBASE_PRIVATE_KEY ou MP_ACCESS_TOKEN.
exports.handler = async () => {
    const config = {
        apiKey: process.env.FIREBASE_WEB_API_KEY,
        authDomain: process.env.FIREBASE_WEB_AUTH_DOMAIN,
        projectId: process.env.FIREBASE_WEB_PROJECT_ID,
        storageBucket: process.env.FIREBASE_WEB_STORAGE_BUCKET,
        messagingSenderId: process.env.FIREBASE_WEB_MESSAGING_SENDER_ID,
        appId: process.env.FIREBASE_WEB_APP_ID
    };

    const missing = Object.keys(config).filter(k => !config[k]);
    if (missing.length > 0) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: `Firebase web config incompleta. Faltam: ${missing.join(', ')}` })
        };
    }

    return { statusCode: 200, body: JSON.stringify(config) };
};
