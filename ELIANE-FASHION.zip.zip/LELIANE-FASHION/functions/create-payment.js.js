const mercadopago = require('mercadopago');
const admin = require('firebase-admin');

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n')
    })
  });
}

exports.handler = async (event) => {
  try {
    // 1) Exige corpo JSON
    const contentType = (event.headers && event.headers['content-type']) || '';
    if (!contentType.includes('application/json')) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Content-Type deve ser application/json' }) };
    }

    // 2) Parse seguro + validação de estrutura
    let payload;
    try {
      payload = JSON.parse(event.body || '');
    } catch (e) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Corpo deve ser JSON válido' }) };
    }

    const items = payload.items;
    if (!Array.isArray(items) || items.length < 1 || items.length > 20) {
      return { statusCode: 400, body: JSON.stringify({ error: 'items deve ser um array de 1 a 20 itens' }) };
    }

    // 3) Preço canônico + estoque via Firestore (SOMENTE LEITURA)
    const db = admin.firestore();
    const checkedItems = [];
    let total = 0;

    for (const item of items) {
      const id = item.id;
      const quantidade = item.quantidade;
      if (typeof id !== 'string' || id.trim() === '') {
        return { statusCode: 400, body: JSON.stringify({ error: 'Cada item precisa de um id' }) };
      }
      if (!Number.isInteger(quantidade) || quantidade < 1 || quantidade > 999) {
        return { statusCode: 400, body: JSON.stringify({ error: 'quantidade deve ser um inteiro entre 1 e 999' }) };
      }

      const doc = await db.collection('produtos').doc(id).get();
      if (!doc.exists) {
        return { statusCode: 400, body: JSON.stringify({ error: `Produto não encontrado: ${id}` }) };
      }
      const produto = doc.data();
      const preco = Number(produto.preco);
      const estoque = Number(produto.estoque);
      if (!Number.isFinite(preco) || preco <= 0) {
        return { statusCode: 400, body: JSON.stringify({ error: `Produto sem preço válido: ${id}` }) };
      }
      if (!Number.isInteger(estoque) || estoque < quantidade) {
        return { statusCode: 400, body: JSON.stringify({ error: `Estoque insuficiente: ${id}` }) };
      }

      checkedItems.push({
        title: produto.nome || id,
        quantity: quantidade,
        unit_price: preco,
        currency_id: 'BRL'
      });
      total = Math.round((total + preco * quantidade) * 100) / 100;
    }

    // 4) Teto anti-abuso
    if (total > 100000) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Valor total acima do permitido' }) };
    }

    // 5) Cria preferência no Mercado Pago
    mercadopago.configure({ access_token: process.env.MP_ACCESS_TOKEN });
    const preference = {
      items: checkedItems,
      back_urls: {
        success: `${process.env.URL_BASE}/?success=true`,
        failure: `${process.env.URL_BASE}/?failure=true`
      },
      auto_return: 'approved'
    };
    const response = await mercadopago.preferences.create(preference);
    return { statusCode: 200, body: JSON.stringify({ id: response.body.id }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
  }
};
