const admin = require('firebase-admin');

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n')
    })
  });
}

// Verifica o token de autenticação e exige o UID de administrador (ADMIN_UID).
async function verifyAdmin(event) {
  const header = event.headers && event.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return { ok: false, statusCode: 401, error: 'Não autorizado' };
  }
  const token = header.split('Bearer ')[1];
  try {
    const decoded = await admin.auth().verifyIdToken(token);
    if (decoded.uid !== process.env.ADMIN_UID) {
      return { ok: false, statusCode: 403, error: 'Acesso negado' };
    }
    return { ok: true, uid: decoded.uid };
  } catch (error) {
    return { ok: false, statusCode: 401, error: 'Token inválido ou expirado' };
  }
}

exports.handler = async (event) => {
  try {
    // 1) Autenticação administrativa
    const auth = await verifyAdmin(event);
    if (!auth.ok) {
      return { statusCode: auth.statusCode, body: JSON.stringify({ error: auth.error }) };
    }

    // 2) Validação da entrada
    let body;
    try {
      body = JSON.parse(event.body || '');
    } catch (e) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Corpo deve ser JSON válido' }) };
    }

    const { id, quantidade } = body;
    if (typeof id !== 'string' || id.trim() === '') {
      return { statusCode: 400, body: JSON.stringify({ error: 'id é obrigatório' }) };
    }
    if (!Number.isInteger(quantidade) || quantidade < 1 || quantidade > 999) {
      return { statusCode: 400, body: JSON.stringify({ error: 'quantidade deve ser um inteiro entre 1 e 999' }) };
    }

    // 3) Baixa de estoque (comportamento original preservado)
    const db = admin.firestore();
    await db.collection('produtos').doc(id).update({
      estoque: admin.firestore.FieldValue.increment(-quantidade)
    });

    return { statusCode: 200, body: JSON.stringify({ success: true }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
  }
};