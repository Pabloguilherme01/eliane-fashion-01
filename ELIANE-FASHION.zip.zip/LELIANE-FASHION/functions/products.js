const admin = require('firebase-admin');

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n')
    })
  });
}

// Verifica o token de autenticação e exige o UID de administrador (ADMIN_UID).
async function verifyAdmin(event) {
  const header = event.headers && event.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return { ok: false, statusCode: 401, error: 'Não autorizado' };
  }
  const token = header.split('Bearer ')[1];
  try {
    const decoded = await admin.auth().verifyIdToken(token);
    if (decoded.uid !== process.env.ADMIN_UID) {
      return { ok: false, statusCode: 403, error: 'Acesso negado' };
    }
    return { ok: true, uid: decoded.uid };
  } catch (error) {
    return { ok: false, statusCode: 401, error: 'Token inválido ou expirado' };
  }
}

exports.handler = async (event) => {
  // Toda operação exige admin autenticado — nada é executado sem isso.
  const auth = await verifyAdmin(event);
  if (!auth.ok) {
    return { statusCode: auth.statusCode, body: JSON.stringify({ error: auth.error }) };
  }

  const db = admin.firestore();
  const method = event.httpMethod || '';

  try {
    if (method === 'GET') {
      // Listar produtos (somente leitura)
      const snapshot = await db.collection('produtos').get();
      const produtos = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      return { statusCode: 200, body: JSON.stringify(produtos) };
    }

    if (method === 'POST') {
      // Criar produto (escrita protegida)
      let payload;
      try {
        payload = JSON.parse(event.body || '');
      } catch (e) {
        return { statusCode: 400, body: JSON.stringify({ error: 'Corpo deve ser JSON válido' }) };
      }

      const nome = payload.nome;
      const preco = Number(payload.preco);
      const estoque = Number(payload.estoque);

      if (typeof nome !== 'string' || nome.trim() === '') {
        return { statusCode: 400, body: JSON.stringify({ error: 'nome é obrigatório' }) };
      }
      if (!Number.isFinite(preco) || preco <= 0) {
        return { statusCode: 400, body: JSON.stringify({ error: 'preco deve ser um número maior que 0' }) };
      }
      if (!Number.isInteger(estoque) || estoque < 0) {
        return { statusCode: 400, body: JSON.stringify({ error: 'estoque deve ser um inteiro maior ou igual a 0' }) };
      }

      const docRef = await db.collection('produtos').add({
        nome: nome.trim(),
        preco: Math.round(preco * 100) / 100,
        estoque
      });
      return { statusCode: 200, body: JSON.stringify({ id: docRef.id, success: true }) };
    }

    return { statusCode: 405, body: JSON.stringify({ error: 'Método não permitido' }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: error.message }) };
  }
};
